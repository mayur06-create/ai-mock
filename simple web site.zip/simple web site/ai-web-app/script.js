// Globals
let isModelLoaded = false;
let isInterviewActive = false;
let detectionInterval;
let interviewTimeline = []; // store objects: { time, emotion, confidence }
let multipleFacesStartTime = null;

// Voice API Globals
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let synth = window.speechSynthesis;
let silenceTimer = null;
let isRecording = false;

// DOM Elements
const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const statusText = document.getElementById("cam-status");
const startBtn = document.getElementById("start-interview-btn");
const endBtn = document.getElementById("end-interview-btn");
const speakBtn = document.getElementById("speak-btn");

const facesText = document.getElementById("faces-text");
const emotionText = document.getElementById("emotion-text");
const confidenceText = document.getElementById("confidence-text");
const warningBanner = document.getElementById("warning-banner");

// Initialize Configs
async function loadModels() {
  statusText.innerText = "Loading Models...";
  const MODEL_URL = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights';
  try {
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL);
    isModelLoaded = true;
    statusText.innerText = "Ready to start interview.";
    startBtn.disabled = false;
  } catch (e) {
    statusText.innerText = "Error loading models.";
  }
}

function initSpeech() {
  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    
    recognition.onresult = (event) => {
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        finalTranscript += event.results[i][0].transcript;
      }
      document.getElementById("prompt").value = finalTranscript;
    };

    recognition.onstart = () => {
      isRecording = true;
      toggleVoiceUI(true);
    };

    recognition.onend = () => {
      isRecording = false;
      toggleVoiceUI(false);
    };
  } else {
    console.warn("Speech Recognition API not supported in this browser.");
  }
  
  // preload voices
  if (synth) synth.getVoices();
}

// Call on load
loadModels();
initSpeech();

function mapEmotionToConfidence(emotion) {
  if (['happy', 'neutral'].includes(emotion)) return "Confident 😎";
  if (['fear', 'sad'].includes(emotion)) return "Nervous 😰";
  if (emotion === 'angry') return "Stressed 😠";
  return "Uncertain 🤔";
}

async function startInterview() {
  if (!isModelLoaded) return;
  isInterviewActive = true;
  interviewTimeline = [];
  multipleFacesStartTime = null;
  warningBanner.classList.add("hidden");
  
  startBtn.disabled = true;
  endBtn.disabled = false;
  speakBtn.disabled = false;
  statusText.innerText = "Interview in progress...";

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    video.srcObject = stream;
    
    // Auto initiate first AI question
    document.getElementById("prompt").value = "Hello, I am ready to start my interview.";
    generateResponse();
    
  } catch (err) {
    statusText.innerText = "Webcam/Mic access denied.";
    console.error(err);
    endInterview();
  }
}

video.addEventListener("play", () => {
  if (!isInterviewActive) return;

  const displaySize = { width: video.videoWidth || 500, height: video.videoHeight || 375 };
  
  detectionInterval = setInterval(async () => {
    if (!isInterviewActive) return clearInterval(detectionInterval);

    try {
      const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceExpressions();

      if (detections && detections.length > 0) {
        
        // Anti-Cheating Logic
        const faceCount = detections.length;
        if (facesText) facesText.innerText = faceCount;
        
        if (faceCount > 1) {
          if (!multipleFacesStartTime) multipleFacesStartTime = Date.now();
          warningBanner.classList.remove("hidden");
          
          if (Date.now() - multipleFacesStartTime > 4000) {
            endInterview(true);
            return;
          }
        } else {
          multipleFacesStartTime = null;
          warningBanner.classList.add("hidden");
        }

        const expressions = detections[0].expressions;
        const dominantEmotion = Object.keys(expressions).reduce((a, b) => expressions[a] > expressions[b] ? a : b);
        const confidenceLevel = mapEmotionToConfidence(dominantEmotion);

        emotionText.innerText = dominantEmotion;
        confidenceText.innerText = confidenceLevel;

        interviewTimeline.push({
          time: new Date(),
          emotion: dominantEmotion,
          confidence: confidenceLevel
        });
      } else {
        if (facesText) facesText.innerText = "0";
        emotionText.innerText = "No Face Found";
        confidenceText.innerText = "--";
        
        multipleFacesStartTime = null;
        warningBanner.classList.add("hidden");
      }
    } catch (e) {}
  }, 1000); 
});

/* -----------------------------------------------------
   VOICE RECORDING STT MACROS
------------------------------------------------------ */
function startRecording() {
  if (!recognition || !isInterviewActive) return;
  document.getElementById("prompt").value = "";
  clearTimeout(silenceTimer);
  
  if (synth.speaking) synth.cancel(); // Interrupt AI if speaking
  recognition.start();
}

function stopRecording() {
  if (!recognition) return;
  recognition.stop();
  
  setTimeout(() => {
    const text = document.getElementById("prompt").value.trim();
    if (!text) {
      speakAI("I didn't quite catch that. Could you please repeat your answer?");
    } else {
      generateResponse();
    }
  }, 300); // Buffer UI delay to allow final text injection
}

function toggleVoiceUI(recording) {
  const speakLayer = document.getElementById("speak-btn");
  const stopLayer = document.getElementById("stop-btn");
  const indicator = document.getElementById("listening-indicator");
  
  if (recording) {
    speakLayer.classList.add("hidden");
    stopLayer.classList.remove("hidden");
    indicator.classList.remove("hidden");
  } else {
    speakLayer.classList.remove("hidden");
    stopLayer.classList.add("hidden");
    indicator.classList.add("hidden");
  }
}

/* -----------------------------------------------------
   SMART TTS LOGIC
------------------------------------------------------ */
function speakAI(text) {
  if (!synth) return;
  
  const cleanText = text.replace(/[*_#`]/g, ''); // strip markdown
  const utterance = new SpeechSynthesisUtterance(cleanText);
  
  const voices = synth.getVoices();
  const proVoice = voices.find(v => v.lang.includes('en-') && (v.name.includes('Google') || v.name.includes('Microsoft'))) || voices[0];
  if (proVoice) utterance.voice = proVoice;
  
  utterance.rate = 1.0;
  
  utterance.onend = () => {
    resetSilenceTimer();
  };
  
  synth.speak(utterance);
}

function resetSilenceTimer() {
  clearTimeout(silenceTimer);
  if (!isInterviewActive) return;
  
  // If 15 seconds pass securely without recording, prompt user
  silenceTimer = setTimeout(() => {
    if (!isRecording && isInterviewActive) {
      speakAI("Are you still there? Please trigger the microphone to speak your answer.");
    }
  }, 15000); 
}

/* -----------------------------------------------------
   INTERVIEW MANAGEMENT
------------------------------------------------------ */
function endInterview(isTerminated = false) {
  isInterviewActive = false;
  startBtn.disabled = false;
  endBtn.disabled = true;
  speakBtn.disabled = true;
  statusText.innerText = isTerminated ? "Terminated (Cheating)" : "Interview Finished.";

  clearTimeout(silenceTimer);
  if (synth.speaking) synth.cancel();
  if (recognition && isRecording) recognition.stop();

  if (detectionInterval) clearInterval(detectionInterval);
  emotionText.innerText = "--";
  confidenceText.innerText = "--";
  if (facesText) facesText.innerText = "0";
  warningBanner.classList.add("hidden");

  // Stop camera + mic cleanly
  if (video.srcObject) {
    video.srcObject.getTracks().forEach(track => track.stop());
    video.srcObject = null;
  }
  
  if (isTerminated === true) {
    generateCheatingReport();
  } else {
    generateReport();
  }
}

function generateCheatingReport() {
  const modal = document.getElementById("report-modal");
  const reportBody = document.getElementById("report-details");
  
  reportBody.innerHTML = `
    <h3 style="color: var(--danger); margin-bottom: 10px; font-size: 1.5rem;">Status: Terminated due to cheating</h3>
    <p style="font-size: 1.1rem; margin-bottom: 15px;"><strong>Reason:</strong> Multiple faces detected during interview.</p>
    <p style="color: var(--text-muted);">Following our strict proctoring guidelines, your session has been permanently closed.</p>
  `;
  modal.classList.remove("hidden");
}

function generateReport() {
  const modal = document.getElementById("report-modal");
  const reportBody = document.getElementById("report-details");

  if (interviewTimeline.length === 0) {
    reportBody.innerHTML = "<p>No emotion data was captured.</p>";
  } else {
    const counts = { Confident: 0, Nervous: 0, Stressed: 0, Uncertain: 0 };
    interviewTimeline.forEach(d => {
      if (d.confidence.includes("Confident")) counts.Confident++;
      if (d.confidence.includes("Nervous")) counts.Nervous++;
      if (d.confidence.includes("Stressed")) counts.Stressed++;
      if (d.confidence.includes("Uncertain")) counts.Uncertain++;
    });

    const total = interviewTimeline.length;
    const firstHalf = interviewTimeline.slice(0, Math.floor(total/2));
    const secondHalf = interviewTimeline.slice(Math.floor(total/2));
    
    let earlyNervous = firstHalf.filter(d => d.confidence.includes("Nervous")).length;
    let lateConfident = secondHalf.filter(d => d.confidence.includes("Confident")).length;
    
    let trendText = "Consistent emotional state.";
    if (earlyNervous > lateConfident && earlyNervous > 0) trendText = "You started nervous but didn't entirely recover. Keep practicing!";
    if (lateConfident > earlyNervous && lateConfident > 0) trendText = "You warmed up during the interview and gained confidence as you went!";
    if (counts.Confident / total > 0.8) trendText = "Excellent job! You remained highly confident throughout the session.";

    reportBody.innerHTML = `
      <p><strong>Total Monitored Duration:</strong> ~${total} seconds</p>
      <ul style="margin-top:10px; list-style:none; padding:0;">
        <li>Confident 😎: ${Math.round((counts.Confident/total)*100)}%</li>
        <li>Nervous 😰: ${Math.round((counts.Nervous/total)*100)}%</li>
        <li>Stressed 😠: ${Math.round((counts.Stressed/total)*100)}%</li>
      </ul>
      <p style="margin-top: 15px; color: #60a5fa;"><strong>Analysis:</strong> ${trendText}</p>
    `;
  }
  modal.classList.remove("hidden");
}

function closeModal() {
  document.getElementById("report-modal").classList.add("hidden");
}

/* Original AI Generative Logic Integration */
async function generateResponse() {
  if (!isInterviewActive && !startBtn.disabled) return alert("Please Start the Interview first.");
  if (statusText.innerText.includes("Terminated")) return alert("This interview has been terminated.");

  clearTimeout(silenceTimer); // disable silence checks while formulating
  const promptElement = document.getElementById("prompt");
  const outputElement = document.getElementById("output");
  const button = document.getElementById("generate-btn");
  const domainElement = document.getElementById("domain");
  
  let prompt = promptElement.value.trim();
  const domain = domainElement ? domainElement.value : "Web Development";

  if (!prompt) return;

  const API_KEY = "AIzaSyCg3kmKfjmyIdF9LSy9NgCXL6A1wgMiJkw";

  const originalBtnText = button.innerHTML;
  button.innerHTML = '<span>Generating AI Audio...</span> <span class="loading"></span>';
  button.disabled = true;
  button.style.opacity = '0.7';
  outputElement.innerHTML = '';

  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{
              text: `You are a professional technical interviewer.\nYour job is to conduct a real interview based on the candidate's selected domain.\n\nDomain: ${domain}\n\nInstructions:\n- Start by asking one interview question at a time.\n- Keep questions conversational and clear (they will be read by Text-to-Speech audio).\n- Avoid using complex markdown codeblocks. Use conversational english.\n- After the user answers, give short feedback, then ask the next question.\n- Keep the conversation natural and professional.\n- Do not break character.`
            }]
          },
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );

    const data = await response.json();
    let output = "";
    if (data.candidates && data.candidates.length > 0) {
      output = data.candidates[0].content.parts[0].text;
      outputElement.innerText = output;
      
      // EMPATHY TTS INJECTION
      const currentEmote = confidenceText ? confidenceText.innerText : "";
      if (currentEmote.includes("Nervous") || currentEmote.includes("Stressed")) {
        speakAI("You seem a bit nervous, take your time. " + output);
      } else {
        speakAI(output);
      }
      
    } else if (data.error) {
      outputElement.innerText = "Error: " + data.error.message;
    }
    
  } catch (error) {
    outputElement.innerText = "Error connecting to AI: " + error.message;
  } finally {
    button.innerHTML = originalBtnText;
    button.disabled = false;
    button.style.opacity = '1';
    promptElement.value = ""; // clear box for next input
  }
}
